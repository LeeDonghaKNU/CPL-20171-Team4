<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<?php
  //echo php info
  $servername = "hbn-rds-demo-mysql.c1s7ooxa8ixo.us-west-2.rds.amazonaws.com";
  $username = "leewonyoung";
  $password = "sodqn123";
  $db_name = "hbn_rds_demo_mysql";
 
  $temp1 = $_GET['id'];   // �Ƶ��̳� �µ� ����  GET['�̸�']   client.print("�̸�=")  �̸��� ���ƾ� �� 


  //create connection
  $mysqli = new mysqli($servername, $username, $password, $db_name);
  // check connection
  if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
  } 

  

  if( $temp1 )
  {
    $sql = "select rfid_id from rfid where rfid_id = '$temp1';"; 
    $result = $mysqli->query($sql);    

    $row = $result->fetch_array(MYSQLI_ASSOC);

    if($temp1 != $row[rfid_id])
    {
      $query = "insert into rfid(rfid_id) values('$temp1')";
    
      if(!$mysqli->query($query))
      {
        printf("error: %s\n", $mysqli->error);
      }
    }
    else
    {
       $query = "delete from rfid where rfid_id = '$temp1';";
    
      if(!$mysqli->query($query))
      {
        printf("error: %s\n", $mysqli->error);
      }
    }
  }
 
  //temp ���̺��� ���� ������ ���ڵ常 �б�
  $sql = "select * from rfid order by no desc limit 1;";
  $result = $mysqli->query($sql);
  $number = 1;


  //$mysqli->close();
?>

<table width= "800" border="1" cellpadding="10">
<tr align="center">
<td bgcolor="#cccccc">NO</td>
<td bgcolor="#cccccc">RFID ID</td>
</tr>

<?
  $row = $result->fetch_array(MYSQLI_ASSOC);
  
  //���ڵ� �� �� ���
  echo "     
    <tr>
      <td> $row[no] </td>
      <td> $row[rfid_id] </td>         
    </tr>     
  ";
  

  $number++;
  //�ϴ� ��ũ��Ʈ: �������� �ڵ� refrash
?>

<script language='javascript'> 
  window.setTimeout('window.location.reload()',3000); //1�ʸ��� ���ø��� ��Ų�� 1000�� 1�ʰ� �ȴ�. 
</script>