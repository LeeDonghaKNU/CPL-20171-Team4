﻿<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<?php
  //echo php info
  $servername = "hbn-rds-demo-mysql.c1s7ooxa8ixo.us-west-2.rds.amazonaws.com";
  $username = "leewonyoung";
  $password = "sodqn123";
  $db_name = "hbn_rds_demo_mysql";
 
  $temp1 = $_GET['temp1'];   // 아두이노 온도 읽음  GET['이름']   client.print("이름=")  이름이 같아야 됨 
  $temp2 = $_GET['temp2'];   // 

  //create connection
  $mysqli = new mysqli($servername, $username, $password, $db_name);
  // check connection
  if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
  } 


 
  if( $temp1 )
  {
    //온습도 데이터를 mysql에 집어 넣는 쿼리
    $query = "insert into temperature(temp1) values('$temp1');";

    if(!$mysqli->query($query))
    {
      printf("error: %s\n", $mysqli->error);
    }
  }
  
  else if( $temp2)
 {
    //온습도 데이터를 mysql에 집어 넣는 쿼리
    $query = "update temperature set temp2 = '$temp2' where temp2 = 0;";

    if(!$mysqli->query($query))
    {
      printf("error: %s\n", $mysqli->error);
    }
  }




  //temp 테이블의 제일 마지막 레코드만 읽기
  $sql = "select * from temperature order by no desc limit 1;";
  $result = $mysqli->query($sql);
  $number = 1;


  //$mysqli->close();
?>

<table width= "800" border="1" cellpadding="10">
<tr align="center">
<td bgcolor="#cccccc">NO</td>
<td bgcolor="#cccccc">냉장실 온도</td>
<td bgcolor="#cccccc">냉동실 온도</td>
</tr>

<?
  $row = $result->fetch_array(MYSQLI_ASSOC);
  
  //레코드 한 행 출력
  echo "     
    <tr>
      <td> $row[no] </td>
      <td> $row[temp1] </td>
      <td> $row[temp2] </td>         
    </tr>     
  ";
  

  $number++;
  //하단 스크립트: 웹페이지 자동 refrash
?>

<script language='javascript'> 
  window.setTimeout('window.location.reload()',3000); //1초마다 리플리쉬 시킨다 1000이 1초가 된다. 
</script>